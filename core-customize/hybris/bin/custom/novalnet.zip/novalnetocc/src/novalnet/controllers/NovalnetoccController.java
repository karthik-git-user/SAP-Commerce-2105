/*
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
package novalnet.controllers;

public class NovalnetoccController
{
	// implement the controller here
}
