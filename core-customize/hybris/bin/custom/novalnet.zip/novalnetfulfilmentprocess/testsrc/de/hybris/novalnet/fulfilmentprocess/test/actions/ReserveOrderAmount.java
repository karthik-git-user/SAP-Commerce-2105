/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.fulfilmentprocess.test.actions;



/**
 * 
 */
public class ReserveOrderAmount extends TestActionTemp
{

	//empty

}
