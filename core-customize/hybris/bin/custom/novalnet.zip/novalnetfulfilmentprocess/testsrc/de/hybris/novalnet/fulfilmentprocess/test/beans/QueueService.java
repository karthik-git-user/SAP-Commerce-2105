/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.fulfilmentprocess.test.beans;



public interface QueueService
{
	//	void init();
	//
	//	ActionExecution pollQueue(final BusinessProcessModel process) throws InterruptedException;
	//
	//	void actionExecuted(final BusinessProcessModel process, final AbstractAction action) throws Exception;
	//
	//	void destroy();
}
